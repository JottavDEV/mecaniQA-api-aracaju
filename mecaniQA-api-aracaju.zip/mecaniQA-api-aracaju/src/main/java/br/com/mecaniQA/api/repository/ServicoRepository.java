package br.com.mecaniQA.api.repository;

import br.com.mecaniQA.api.model.Servico;

import java.util.ArrayList;
import java.util.List;

public class ServicoRepository {

    // ===================== SINGLETON =====================

    private static ServicoRepository instance;

    // ===================== ATRIBUTOS =====================

    private final List<Servico> servicos;

    // ===================== CONSTRUTOR =====================

    private ServicoRepository() {
        servicos = new ArrayList<>();
    }

    // ===================== SINGLETON =====================

    public static ServicoRepository getInstance() {
        if (instance == null) {
            instance = new ServicoRepository();
        }

        return instance;
    }

    // ===================== CREATE =====================

    public Servico salvar(Servico servico) {
        servicos.add(servico);
        return servico;
    }

    // ===================== READ =====================

    public List<Servico> getServicos() {
        return servicos;
    }

    public Servico buscarPorId(long codigoServico) {

        for (Servico servico : servicos) {

            if (servico.getCodigoServico() == codigoServico) {
                return servico;
            }
        }

        return null;
    }

    // ===================== UPDATE =====================

    public Servico atualizar(long codigoServico, Servico servicoAtualizado) {

        Servico servico = buscarPorId(codigoServico);

        if (servico == null) {
            return null;
        }

        servico.setNomeServico(
                servicoAtualizado.getNomeServico()
        );

        servico.setDescricaoServico(
                servicoAtualizado.getDescricaoServico()
        );

        servico.setTempoEstimadoMinutos(
                servicoAtualizado.getTempoEstimadoMinutos()
        );

        servico.setCustoTabelado(
                servicoAtualizado.getCustoTabelado()
        );

        servico.setDataAtualizacao(
                servicoAtualizado.getDataAtualizacao()
        );

        return servico;
    }

    // ===================== DELETE =====================

    public boolean deletar(long codigoServico) {

        Servico servico = buscarPorId(codigoServico);

        if (servico == null) {
            return false;
        }

        servicos.remove(servico);

        return true;
    }
}