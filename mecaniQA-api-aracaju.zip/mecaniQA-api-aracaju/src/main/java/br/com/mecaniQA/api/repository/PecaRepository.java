package br.com.mecaniQA.api.repository;

import br.com.mecaniQA.api.model.Peca;

import java.util.ArrayList;
import java.util.List;

public class PecaRepository {

    private static PecaRepository instance;

    private final List<Peca> pecas;

    private PecaRepository() {
        pecas = new ArrayList<>();
    }

    public static PecaRepository getInstance() {

        if (instance == null) {
            instance = new PecaRepository();
        }

        return instance;
    }

    // CREATE

    public Peca salvar(Peca peca) {

        pecas.add(peca);

        return peca;
    }

    // READ

    public List<Peca> listarTodas() {

        return pecas;
    }

    public Peca buscarPorId(long codigoSKU) {

        for (Peca peca : pecas) {

            if (peca.getCodigoSKU() == codigoSKU) {
                return peca;
            }
        }

        return null;
    }

    // UPDATE

    public Peca atualizar(
            long codigoSKU,
            Peca pecaAtualizada) {

        Peca peca = buscarPorId(codigoSKU);

        if (peca == null) {
            return null;
        }

        peca.setNome(pecaAtualizada.getNome());
        peca.setCodigobarras(pecaAtualizada.getCodigobarras());
        peca.setFornecedor(pecaAtualizada.getFornecedor());
        peca.setQuantidade(pecaAtualizada.getQuantidade());
        peca.setPrecoCusto(pecaAtualizada.getPrecoCusto());
        peca.setPrecoVenda(pecaAtualizada.getPrecoVenda());
        peca.setTamanho(pecaAtualizada.getTamanho());
        peca.setCor(pecaAtualizada.getCor());
        peca.setCategoriaPeca(
                pecaAtualizada.getCategoriaPeca()
        );
        peca.setDataAtualizacao(
                pecaAtualizada.getDataAtualizacao()
        );

        return peca;
    }

    // DELETE

    public boolean deletar(long codigoSKU) {

        Peca peca = buscarPorId(codigoSKU);

        if (peca == null) {
            return false;
        }

        pecas.remove(peca);

        return true;
    }
}