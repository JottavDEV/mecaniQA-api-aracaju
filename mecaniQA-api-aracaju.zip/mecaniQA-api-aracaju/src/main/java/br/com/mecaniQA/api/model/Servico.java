package br.com.mecaniQA.api.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "servicos")
public class Servico {

    // ===================== ATRIBUTOS =====================

    @Id
    private long codigoServico;

    private String nomeServico;
    private String descricaoServico;
    private int tempoEstimadoMinutos;
    private double custoTabelado;
    private LocalDateTime dataCriacao;
    private LocalDateTime dataAtualizacao;

    // ===================== CONSTRUTOR =====================

    public Servico() {
    }

    // ===================== GETTERS =====================

    public long getCodigoServico() {
        return codigoServico;
    }

    public String getNomeServico() {
        return nomeServico;
    }

    public String getDescricaoServico() {
        return descricaoServico;
    }

    public int getTempoEstimadoMinutos() {
        return tempoEstimadoMinutos;
    }

    public double getCustoTabelado() {
        return custoTabelado;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    // ===================== SETTERS =====================

    public void setCodigoServico(long novoCodigoServico) {
        this.codigoServico = novoCodigoServico;
    }

    public void setNomeServico(String novoNomeServico) {
        this.nomeServico = novoNomeServico;
    }

    public void setDescricaoServico(String novoDescricaoServico) {
        this.descricaoServico = novoDescricaoServico;
    }

    public void setTempoEstimadoMinutos(
            int novoTempoEstimadoMinutos) {

        this.tempoEstimadoMinutos = novoTempoEstimadoMinutos;
    }

    public void setCustoTabelado(double novoCustoTabelado) {
        this.custoTabelado = novoCustoTabelado;
    }

    public void setDataCriacao(LocalDateTime novaDataCriacao) {
        this.dataCriacao = novaDataCriacao;
    }

    public void setDataAtualizacao(
            LocalDateTime novaDataAtualizacao) {

        this.dataAtualizacao = novaDataAtualizacao;
    }
}