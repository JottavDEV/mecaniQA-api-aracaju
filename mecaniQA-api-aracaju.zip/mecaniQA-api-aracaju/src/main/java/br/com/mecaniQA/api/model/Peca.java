package br.com.mecaniQA.api.model;

import br.com.mecaniQA.api.enums.Categorias;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "pecas")
public class Peca {

    // ===================== ATRIBUTOS =====================

    @Id
    private long codigoSKU;

    private String nome;

    private long codigobarras;

    private String fornecedor;

    private int quantidade;

    private double precoCusto;

    private double precoVenda;

    private LocalDateTime dataCadastro;

    private LocalDateTime dataAtualizacao;

    private String tamanho;

    private String cor;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Categorias categoriaPeca;


    // ===================== CONSTRUTOR =====================

    public Peca() {
    }


    // ===================== GETTERS =====================

    public long getCodigoSKU() {
        return codigoSKU;
    }

    public String getNome() {
        return nome;
    }

    public long getCodigobarras() {
        return codigobarras;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getPrecoCusto() {
        return precoCusto;
    }

    public double getPrecoVenda() {
        return precoVenda;
    }

    public LocalDateTime getDataCadastro() {
        return dataCadastro;
    }

    public LocalDateTime getDataAtualizacao() {
        return dataAtualizacao;
    }

    public String getTamanho() {
        return tamanho;
    }

    public String getCor() {
        return cor;
    }

    public Categorias getCategoriaPeca() {
        return categoriaPeca;
    }


    // ===================== SETTERS =====================

    public void setCodigoSKU(long novoCodigoSKU) {
        this.codigoSKU = novoCodigoSKU;
    }

    public void setNome(String novoNome) {
        this.nome = novoNome;
    }

    public void setCodigobarras(long novoCodigobarras) {
        this.codigobarras = novoCodigobarras;
    }

    public void setFornecedor(String novoFornecedor) {
        this.fornecedor = novoFornecedor;
    }

    public void setQuantidade(int novaQuantidade) {
        this.quantidade = novaQuantidade;
    }

    public void setPrecoCusto(double novoPrecoCusto) {
        this.precoCusto = novoPrecoCusto;
    }

    public void setPrecoVenda(double novoPrecoVenda) {
        this.precoVenda = novoPrecoVenda;
    }

    public void setDataCadastro(LocalDateTime novaDataCadastro) {
        this.dataCadastro = novaDataCadastro;
    }

    public void setDataAtualizacao(LocalDateTime novaDataAtualizacao) {
        this.dataAtualizacao = novaDataAtualizacao;
    }

    public void setTamanho(String novoTamanho) {
        this.tamanho = novoTamanho;
    }

    public void setCor(String novaCor) {
        this.cor = novoCor;
    }

    public void setCategoriaPeca(Categorias novaCategoriaPeca) {
        this.categoriaPeca = novaCategoriaPeca;
    }

}